# Binary relevance evaluation analysis

- Source: `/tmp/opencode/news-current-policy-v2.json`
- Source SHA-256: `662d9f467e98abf89479f65e163d8ae42c567ac9741205f7a969ecc9e5f28a22`
- Source artifact: `083d5ae5ba73686511f5eb01ce770dc2e5826de22cf27df76e205bd9b946216a`
- Question: `relevant` (`5d77b7025c568fec62748abacd89920ea6ddfb5e5d9a4aa272d2e4baa9d2407a`)
- Shape: 3 targets x 3 trials x 174 cases
- Aggregation: descriptive only; repeated trials use the same cases and are not independent.

## Registered gates

| Target | Coverage | Quality | Deployment eligible | Failures |
| --- | ---: | ---: | ---: | --- |
| `openrouter-gemini-2.5-flash` | yes | no | no | trial 1: positive controls 0.967480 != 1.0; trial 1: recall 0.967480 != 1.0; trial 2: positive controls 0.959350 != 1.0; trial 2: recall 0.959350 != 1.0; trial 3: positive controls 0.951220 != 1.0; trial 3: recall 0.951220 != 1.0 |
| `openrouter-gemini-3.8-flash` | yes | no | no | trial 1: positive controls 0.926829 != 1.0; trial 1: recall 0.926829 != 1.0; trial 2: positive controls 0.918699 != 1.0; trial 2: recall 0.918699 != 1.0; trial 3: positive controls 0.918699 != 1.0; trial 3: recall 0.918699 != 1.0 |
| `typesafe-jev` | yes | yes | yes | none |

## Trial results

| Target | Trial | TP | TN | FP | FN | Precision (95% exact CI) | Recall (95% exact CI) | Controls (95% exact CI) | Requests | Tokens | Cost USD | Cost/article | Cost/1000 | Attempt p50/p95 ms | Article p50/p95 ms |
| --- | --- | ---: | ---: | ---: | ---: | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | --- |
| `openrouter-gemini-2.5-flash` | `current-policy-v2-20260919:trial-001` | 119 | 23 | 28 | 4 | 0.8095 (0.7366-0.8695) | 0.9675 (0.9188-0.9911) | 0.9675 (0.9188-0.9911) | 174 | 289524 | 0.088771200 | 0.000510179 | 0.510179 | 675.0/945.2 | 675.0/945.2 |
| `openrouter-gemini-2.5-flash` | `current-policy-v2-20260919:trial-002` | 118 | 23 | 28 | 5 | 0.8082 (0.7349-0.8686) | 0.9593 (0.9077-0.9867) | 0.9593 (0.9077-0.9867) | 174 | 289524 | 0.088771200 | 0.000510179 | 0.510179 | 607.5/834.9 | 607.5/834.9 |
| `openrouter-gemini-2.5-flash` | `current-policy-v2-20260919:trial-003` | 117 | 23 | 28 | 6 | 0.8069 (0.7331-0.8677) | 0.9512 (0.8968-0.9819) | 0.9512 (0.8968-0.9819) | 174 | 289524 | 0.088771200 | 0.000510179 | 0.510179 | 620.0/857.0 | 620.0/857.0 |
| `openrouter-gemini-3.8-flash` | `current-policy-v2-20260919:trial-001` | 114 | 39 | 12 | 9 | 0.9048 (0.8395-0.9498) | 0.9268 (0.8656-0.9660) | 0.9268 (0.8656-0.9660) | 174 | 417427 | 0.681119250 | 0.003914478 | 3.914478 | 3305.5/5485.8 | 3305.5/5485.8 |
| `openrouter-gemini-3.8-flash` | `current-policy-v2-20260919:trial-002` | 113 | 39 | 12 | 10 | 0.9040 (0.8383-0.9494) | 0.9187 (0.8556-0.9603) | 0.9187 (0.8556-0.9603) | 174 | 417350 | 0.680830500 | 0.003912819 | 3.912819 | 3235.5/5429.7 | 3235.5/5429.7 |
| `openrouter-gemini-3.8-flash` | `current-policy-v2-20260919:trial-003` | 113 | 39 | 12 | 10 | 0.9040 (0.8383-0.9494) | 0.9187 (0.8556-0.9603) | 0.9187 (0.8556-0.9603) | 174 | 417721 | 0.682221750 | 0.003920815 | 3.920815 | 3430.5/5993.3 | 3430.5/5993.3 |
| `typesafe-jev` | `current-policy-v2-20260919:trial-001` | 123 | 23 | 28 | 0 | 0.8146 (0.7433-0.8731) | 1.0000 (0.9705-1.0000) | 1.0000 (0.9705-1.0000) | 174 | 369135 | 0.015342894 | 0.000088178 | 0.088178 | 642.5/824.7 | 642.5/824.7 |
| `typesafe-jev` | `current-policy-v2-20260919:trial-002` | 123 | 24 | 27 | 0 | 0.8200 (0.7490-0.8779) | 1.0000 (0.9705-1.0000) | 1.0000 (0.9705-1.0000) | 174 | 369135 | 0.015342894 | 0.000088178 | 0.088178 | 643.0/832.0 | 643.0/832.0 |
| `typesafe-jev` | `current-policy-v2-20260919:trial-003` | 123 | 23 | 28 | 0 | 0.8146 (0.7433-0.8731) | 1.0000 (0.9705-1.0000) | 1.0000 (0.9705-1.0000) | 174 | 369135 | 0.015342894 | 0.000088178 | 0.088178 | 636.0/820.0 | 636.0/820.0 |

## Target aggregates

These are descriptive summaries across repeated runs. No pooled confidence interval is reported.

| Target | Errors by trial | Mean cost/article USD | Projected cost/1000 USD | Median trial article p95 ms | Total requests | Total tokens | Total cost USD |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `openrouter-gemini-2.5-flash` | 32/33/34 | 0.000510179 | 0.510179 | 857.0 | 522 | 868572 | 0.266313600 |
| `openrouter-gemini-3.8-flash` | 21/22/22 | 0.003916037 | 3.916037 | 5485.8 | 522 | 1252498 | 2.044171500 |
| `typesafe-jev` | 28/27/28 | 0.000088178 | 0.088178 | 824.7 | 522 | 1107405 | 0.046028682 |

## Paired correctness

- `current-policy-v2-20260919:trial-001` `openrouter-gemini-2.5-flash` vs `openrouter-gemini-3.8-flash`: both correct 134, first-only correct 8, second-only correct 19, both wrong 13; exact McNemar p=0.052239.
- `current-policy-v2-20260919:trial-001` `openrouter-gemini-2.5-flash` vs `typesafe-jev`: both correct 136, first-only correct 6, second-only correct 10, both wrong 22; exact McNemar p=0.454498.
- `current-policy-v2-20260919:trial-001` `openrouter-gemini-3.8-flash` vs `typesafe-jev`: both correct 137, first-only correct 16, second-only correct 9, both wrong 12; exact McNemar p=0.229523.
- `current-policy-v2-20260919:trial-002` `openrouter-gemini-2.5-flash` vs `openrouter-gemini-3.8-flash`: both correct 132, first-only correct 9, second-only correct 20, both wrong 13; exact McNemar p=0.0614283.
- `current-policy-v2-20260919:trial-002` `openrouter-gemini-2.5-flash` vs `typesafe-jev`: both correct 136, first-only correct 5, second-only correct 11, both wrong 22; exact McNemar p=0.210114.
- `current-policy-v2-20260919:trial-002` `openrouter-gemini-3.8-flash` vs `typesafe-jev`: both correct 137, first-only correct 15, second-only correct 10, both wrong 12; exact McNemar p=0.424356.
- `current-policy-v2-20260919:trial-003` `openrouter-gemini-2.5-flash` vs `openrouter-gemini-3.8-flash`: both correct 132, first-only correct 8, second-only correct 20, both wrong 14; exact McNemar p=0.0356981.
- `current-policy-v2-20260919:trial-003` `openrouter-gemini-2.5-flash` vs `typesafe-jev`: both correct 134, first-only correct 6, second-only correct 12, both wrong 22; exact McNemar p=0.237885.
- `current-policy-v2-20260919:trial-003` `openrouter-gemini-3.8-flash` vs `typesafe-jev`: both correct 136, first-only correct 16, second-only correct 10, both wrong 12; exact McNemar p=0.32694.

## Cross-trial stability

### `openrouter-gemini-2.5-flash`

- Unanimous verdict rate: 0.971264 (169/174).
- Adjacent-trial verdict flips: 8.
- Stable false positives: `local-development-is-not-national`, `foreign-war-without-romania-impact-is-rejected`, `local-traffic-closure-is-rejected`, `administrative-document-fees-are-rejected`, `2026-09-02-1f887334792f-article-1-relevance`, `2026-09-02-1f887334792f-article-5-relevance`, `2026-09-02-3e1ba508a6b8-article-1-relevance`, `2026-09-03-d3c5758cca9f-article-6-relevance`, `2026-09-03-3b44da17295c-article-1-relevance`, `2026-09-03-3db5ddadecaa-article-1-relevance`, `2026-09-03-a8a95b7bb506-article-1-relevance`, `2026-09-03-c8533e2c947b-article-1-relevance`, `2026-09-03-c8533e2c947b-article-2-relevance`, `2026-09-03-c8533e2c947b-article-3-relevance`, `2026-09-03-c8533e2c947b-article-4-relevance`, `2026-09-04-1f804ca36992-article-1-relevance`, `2026-09-04-1f804ca36992-article-2-relevance`, `2026-09-04-d00e88f366f8-article-1-relevance`, `2026-09-05-0dddd2dfdf71-article-1-relevance`, `2026-09-05-5f45ea151cfb-article-1-relevance`, `2026-09-05-7fdc41c75916-article-1-relevance`, `2026-09-05-b43781a6f6eb-article-1-relevance`, `2026-09-05-bd67d33abb91-article-1-relevance`, `2026-09-05-a4b4d53aefee-article-1-relevance`, `2026-09-05-bd6525dbc974-article-1-relevance`, `2026-09-06-76679f1b4bef-article-1-relevance-aa325a946992`, `sep10-subject-23-article-1-relevance`.
- Stable false negatives: `sep10-subject-15-article-1-relevance`, `sep10-subject-25-article-2-relevance`, `sep10-subject-26-article-1-relevance`.
- Unstable IDs: `2026-09-02-6ae1adffcb78-article-1-relevance`, `2026-09-04-23602144d312-article-1-relevance`, `2026-09-04-b192911bcc20-article-1-relevance`, `2026-09-05-0f4d53ac2539-article-1-relevance`, `sep10-subject-08-article-1-relevance`.

### `openrouter-gemini-3.8-flash`

- Unanimous verdict rate: 0.948276 (165/174).
- Adjacent-trial verdict flips: 11.
- Stable false positives: `administrative-document-fees-are-rejected`, `2026-09-02-3e1ba508a6b8-article-1-relevance`, `2026-09-03-c8533e2c947b-article-1-relevance`, `2026-09-03-c8533e2c947b-article-2-relevance`, `2026-09-03-c8533e2c947b-article-3-relevance`, `2026-09-03-c8533e2c947b-article-4-relevance`, `2026-09-04-1f804ca36992-article-1-relevance`, `2026-09-04-1f804ca36992-article-2-relevance`, `2026-09-04-d00e88f366f8-article-1-relevance`, `2026-09-05-b43781a6f6eb-article-1-relevance`, `2026-09-06-76679f1b4bef-article-1-relevance-aa325a946992`.
- Stable false negatives: `2026-09-02-2f1c45ed3835-article-3-relevance`, `2026-09-03-1a6c0fe83840-article-1-relevance`, `2026-09-05-920b9cfa8289-article-1-relevance`, `2026-09-05-c7407ea50677-article-1-relevance`, `2026-09-05-d33d167239fa-article-1-relevance`, `sep10-subject-26-article-1-relevance`.
- Unstable IDs: `local-development-is-not-national`, `2026-09-02-2f1c45ed3835-article-1-relevance`, `2026-09-02-2f1c45ed3835-article-4-relevance`, `2026-09-02-2f1c45ed3835-article-5-relevance`, `2026-09-03-a8a95b7bb506-article-1-relevance`, `2026-09-04-b192911bcc20-article-1-relevance`, `sep10-subject-09-article-3-relevance`, `sep10-subject-10-article-1-relevance`, `sep10-subject-29-article-1-relevance`.

### `typesafe-jev`

- Unanimous verdict rate: 0.971264 (169/174).
- Adjacent-trial verdict flips: 8.
- Stable false positives: `local-development-is-not-national`, `local-traffic-closure-is-rejected`, `administrative-document-fees-are-rejected`, `2026-09-02-3e1ba508a6b8-article-1-relevance`, `2026-09-03-3b44da17295c-article-1-relevance`, `2026-09-03-3db5ddadecaa-article-1-relevance`, `2026-09-03-a8a95b7bb506-article-1-relevance`, `2026-09-03-c8533e2c947b-article-1-relevance`, `2026-09-03-c8533e2c947b-article-2-relevance`, `2026-09-03-c8533e2c947b-article-3-relevance`, `2026-09-03-c8533e2c947b-article-4-relevance`, `2026-09-04-1f804ca36992-article-1-relevance`, `2026-09-04-1f804ca36992-article-2-relevance`, `2026-09-04-d00e88f366f8-article-1-relevance`, `2026-09-05-0dddd2dfdf71-article-1-relevance`, `2026-09-05-0edbe20e8874-article-1-relevance`, `2026-09-05-5f45ea151cfb-article-1-relevance`, `2026-09-05-8459f719fd51-article-1-relevance`, `2026-09-05-b43781a6f6eb-article-1-relevance`, `2026-09-05-bd67d33abb91-article-1-relevance`, `2026-09-05-0f4d53ac2539-article-1-relevance`, `2026-09-05-a4b4d53aefee-article-1-relevance`, `2026-09-05-bd6525dbc974-article-1-relevance`, `2026-09-05-0f90c6cf92f9-article-1-relevance-6f523a1593fd`, `2026-09-06-76679f1b4bef-article-1-relevance-aa325a946992`.
- Stable false negatives: none.
- Unstable IDs: `2026-09-02-1f887334792f-article-2-relevance`, `2026-09-02-6ae1adffcb78-article-1-relevance`, `2026-09-03-d3c5758cca9f-article-5-relevance`, `2026-09-05-327f01f36f59-article-1-relevance`, `2026-09-05-40c0bd9c9ba3-article-1-relevance`.

## Pareto analysis

Dimensions are minimized: worst-trial quality errors, mean cost/article, and median trial article p95 latency.

- All-target frontier: `openrouter-gemini-3.8-flash`, `typesafe-jev`.
- Deployment-eligible frontier: `typesafe-jev`.

| Target | Worst trial errors | Mean cost/article USD | Median trial p95 ms | Gate eligible | Non-dominated among all |
| --- | ---: | ---: | ---: | ---: | ---: |
| `openrouter-gemini-2.5-flash` | 34 | 0.000510179 | 857.0 | no | no |
| `openrouter-gemini-3.8-flash` | 22 | 0.003916037 | 5485.8 | no | yes |
| `typesafe-jev` | 28 | 0.000088178 | 824.7 | yes | yes |
